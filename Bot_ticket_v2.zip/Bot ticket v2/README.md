# Bot ticket v2
Este projeto é liçenciado pela equipe Leinad Code, qualquer modificação/alteração de qualquer em mensagems que represente a equipe de desenvolvimento, podem estar sujeito a problema judicias.

Copyright ©️ Leinad Store 2022 - 2023

# Copyright
This project has copyright, the current company responsible for the project is Leinad Code (Web application development company). And if another sender has access to any project file without a permission document, he can be punished under Federal Law.